
<?php

error_reporting( ~E_NOTICE );
require_once 'config.php';

session_start();
if(!isset($_SESSION['login_user']))
	{
		header("Location:login.php");
	}

if(isset($_GET['edit']))
{
    $sql="SELECT * FROM tbl_lesson WHERE lessonid=".$_GET['edit']." ";
    $result = $db->query($sql);
    if ($result->num_rows > 0)
    {
      
        $row=$result->fetch_assoc();
        $title = $row['lesson_title'];
        $course = $row['course'];
        $videourl = $row['videourl'];
        $previewimage = $row['previewimage'];
    }
}

if(isset($_POST['btnsubmit']))
{
    $title = $_POST['title'];
    $course = $_POST['course'];
    $videourl = $_POST['videourl'];

    
	$imgFile = $_FILES['previewimage']['name'];
	$tmp_dir = $_FILES['previewimage']['tmp_name'];
    $imgSize = $_FILES['previewimage']['size'];

    if(isset($_GET['edit']))
    {
        $sql = "UPDATE tbl_lesson
                SET title='$title',course='$course',videourl='$videourl'
                WHERE lessonid=".$_GET['edit']." ";

                                    
        mysqli_query($db, $sql);


        echo( $sql);
            // echo('Successfully Updated ...');
    }
    else
    {
        if(empty($title))
        {
            $errMSG = "Please Enter title.";
        }
        elseif(empty($course))
        {
            $errMSG = "Please Choose course.";
        }
        elseif(empty($videourl))
        {
            $errMSG = "Please paste video url.";
        }
        elseif(empty($imgFile))
        {
            $errMSG = "Please choose image.";
        }
        else
        {
            // $successMSG= " Data added successfully";
            $upload_dir = 'assets/images/video/'; // upload directory 
            $imgExt = strtolower(pathinfo($imgFile,PATHINFO_EXTENSION)); // get image extension
      
			// valid image extensions
			$valid_extensions = array('jpeg', 'jpg', 'png', 'gif'); // valid extensions
		
			// rename uploading image
            $pimage = rand(1000,100000).".".$imgExt;
				
 

			// allow valid image file formats
            if(in_array($imgExt, $valid_extensions))
            {			
                // Check file size '5MB'
                if($imgSize < 5000000)				
                {
                    $res = move_uploaded_file($tmp_dir,$upload_dir.$pimage);
                    // echo $res;
                    if($res)
                    {
                        $sql = "INSERT INTO tbl_lesson(lesson_title,course,videourl,previewimage) VALUES('$title','$course','$videourl','$pimage')";
                        mysqli_query($db, $sql);
                
                        $successMSG = "Successfully added lesson";
                    }
                    else
                    {
                        $errMSG = "Unable to upload image";
                    }
            
                }
                else
                {
                    $errMSG = "Sorry, your file is too large.";
                }
			}
            else
            {
				$errMSG = "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";		
			}

        }
    

}
}

?>








<?php include 'header.php'; ?>

 <!-- Header Layout Content -->
 <div class="mdk-header-layout__content">

<div data-push data-responsive-width="992px" class="mdk-drawer-layout js-mdk-drawer-layout">
    <div class="mdk-drawer-layout__content page ">

        <div class="container-fluid page__container">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="instructor-dashboard.html">Home</a></li>
                <li class="breadcrumb-item active">Courses</li>
            </ol>
            <h1 class="h2">Add Lesson</h1>
            <div class="card">
                <div class="card-body">
                <form class="form-horizontal" method="post" enctype="multipart/form-data">
                        <div class="form-group row">
                            <label for="avatar" class="col-sm-3 col-form-label form-label">Preview</label>
                            <div class="col-sm-9">
                                <div class="media align-items-center">
                                    <div class="media-left">
                                        <img src="#" id="imgPrev" width="100" class="rounded">
                                    </div>
                                    <div class="media-body">
                                        <div class="custom-file" style="width: auto;">
                                            <input type="file" name="previewimage" id="avatar" class="custom-file-input">
                                            <label for="avatar" class="custom-file-label">Choose file</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="title" class="col-md-3 col-form-label form-label">Title</label>
                            <div class="col-md-6">
                                <input id="title" name="title" value="<?php echo $title; ?>" type="text" class="form-control" placeholder="Write an awesome title">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="course" class="col-md-3 col-form-label form-label">Course</label>
                            <div class="col-md-4">
                                <select id="course" name="course" class="custom-control custom-select form-control">
            <?php
                $dd_res="SELECT * FROM tbl_course";
                $result = $db->query($dd_res);

                if ($result->num_rows > 0) {
                while($row=$result->fetch_assoc())
                {
                  extract($row);
            ?>
                                    <option value="<?php echo $courseid; ?>" <?php if($courseid==$course) echo "selected='selected'"; ?>><?php echo $title; ?></option>
                <?php } } ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3 col-form-label form-label">Upload Video</label>
                            <div class="col-md-9">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <input type="text" class="form-control" name="videourl" value="<?php echo $videourl; ?>" />
                                            <small class="form-text text-muted d-flex align-items-center">
                                                <i class="material-icons font-size-16pt mr-1">ondemand_video</i>
                                                <span class="icon-text">Paste Video</span>
                                            </small>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <div class="embed-responsive embed-responsive-16by9">
                                                <iframe class="embed-responsive-item" src="<?php echo $videourl; ?>" allowfullscreen=""></iframe>
                                            </div>
                                        </div>
                                    </div>
                                   
                                </div>
                            </div>
                        </div>
                        <div class="form-group row">
                                    <div class="col-md-3">   
                                        <button type="submit" name="btnsubmit" class="btn btn-success">SAVE</button>
                                    </div>
                                    <div class="col-md-6">
                                    <?php
	if(isset($errMSG)){
			?>
            <div class="alert alert-danger">
            	<span class="glyphicon glyphicon-info-sign"></span> <strong><?php echo $errMSG; ?></strong>
            </div>
            <?php
	}
	else if(isset($successMSG)){
		?>
        <div class="alert alert-success">
              <strong><span class="glyphicon glyphicon-info-sign"></span> <?php echo $successMSG; ?></strong>
        </div>
        <?php
	}
	?>  
    </div>
                                    
                                    </div>
                    </form>
                </div>
            </div>
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Files</h4>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <form id="my-awesome-dropzone" action="http://learnplus-bootstrap.frontendmatter.com/target" class="dropzone"></form>
                        </div>
                        <div class="col-md-6">
                            <div data-toggle="tree">
                                <ul style="display: none;">
                                    <li class="folder expanded">
                                        lesson files
                                        <ul>
                                            <li>lesson-1-install.zip</li>
                                            <li>lesson-1-steps.zip</li>
                                        </ul>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>





<?php include 'footer.php'; ?>