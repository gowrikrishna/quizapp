<?php 
error_reporting( ~E_NOTICE );
require_once 'config.php';

session_start();
if(!isset($_SESSION['login_user']))
	{
		header("Location:login.php");
	}

if(isset($_GET['id']))
{
    $sql="SELECT * FROM tbl_lesson inner join tbl_course on tbl_lesson.course=tbl_course.courseid where course=".$_GET['id']." ORDER BY lessonid ASC LIMIT 1";
    $result = $db->query($sql);
    if ($result->num_rows > 0)
    {
        while($row=$result->fetch_assoc())
        {
            $title = $row['lesson_title'];
            $description = $row['description'];
            $url = $row['videourl'];
        



        }
    }
}
else
{
    $sql="SELECT * FROM tbl_lesson inner join tbl_course on tbl_lesson.course=tbl_course.courseid ORDER BY lessonid ASC LIMIT 1";
    $result = $db->query($sql);
    if ($result->num_rows > 0)
    {
        while($row=$result->fetch_assoc())
        {
            $title = $row['lesson_title'];
            $description = $row['description'];
            $url = $row['videourl'];
        



        }
    }
}








?>
<?php
include 'header.php';
?>

  <!-- Header Layout Content -->
  <div class="mdk-header-layout__content">

<div data-push data-responsive-width="992px" class="mdk-drawer-layout js-mdk-drawer-layout">
    <div class="mdk-drawer-layout__content page ">

        <div class="container-fluid page__container">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="dashboard.html">Home</a></li>
                <li class="breadcrumb-item"><a href="student-browse-courses.html">Courses</a></li>
                <li class="breadcrumb-item active"><?php echo $title; ?></li>
            </ol>
            <h1 class="h2"><?php echo $title; ?></h1>
            <div class="row">
                <div class="col-md-8">
                    <div class="card">
                        <div class="embed-responsive embed-responsive-16by9">
                            <iframe class="embed-responsive-item" src="<?php echo $url; ?>" allowfullscreen=""></iframe>
                        </div>
                        <div class="card-body">
                            <p><?php echo $description; ?></p>
                            
                           
                                
                            <a href="take-quiz.php?id=<?php echo $_GET['id'];   ?>" class="btn btn-primary btn-block flex-column">
                                <!-- <i class="fas fa-question-circle"></i> -->
                                 Finished chapter? Take Quiz now.
                            </a>
                        </div>
                    </div>

                    <!-- Lessons -->
                    <ul class="card list-group list-group-fit">
                        <li class="list-group-item">
                            <div class="media">
                                <div class="media-left">
                                    <div class="text-muted">1.</div>
                                </div>
                                <div class="media-body">
                                    <a href="#">Installation</a>
                                </div>
                                <div class="media-right">
                                    <small class="text-muted-light">2:03</small>
                                </div>
                            </div>
                        </li>
                        <li class="list-group-item active">
                            <div class="media">
                                <div class="media-left">
                                    2.
                                </div>
                                <div class="media-body">
                                    <a class="text-white" href="#">The MVC architectural pattern</a>
                                </div>
                                <div class="media-right">
                                    <small>25:01</small>
                                </div>
                            </div>
                        </li>
                        <li class="list-group-item">
                            <div class="media">
                                <div class="media-left">
                                    <div class="text-muted">3.</div>
                                </div>
                                <div class="media-body">
                                    <a href="#">Database Models</a>
                                </div>
                                <div class="media-right">
                                    <small class="text-muted-light">12:10</small>
                                </div>
                            </div>
                        </li>
                        <li class="list-group-item">
                            <div class="media">
                                <div class="media-left">
                                    <div class="text-muted">4.</div>
                                </div>
                                <div class="media-body">
                                    <a href="#">Database Access</a>
                                </div>
                                <div class="media-right">
                                    <small class="text-muted-light">1:25</small>
                                </div>
                            </div>
                        </li>
                        <li class="list-group-item">
                            <div class="media">
                                <div class="media-left">
                                    <div class="text-muted">5.</div>
                                </div>
                                <div class="media-body">
                                    <a href="#">Eloquent Basics</a>
                                </div>
                                <div class="media-right">
                                    <small class="text-muted-light">22:30</small>
                                </div>
                            </div>
                        </li>
                        <li class="list-group-item">
                            <div class="media">
                                <div class="media-left">
                                    <div class="text-muted">6.</div>
                                </div>
                                <div class="media-body">
                                    <a href="#">Take Quiz</a>
                                </div>
                                <div class="media-right">
                                    <small class="text-muted-light">10:00</small>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-body">
                            <a href="#" class="btn btn-primary btn-block flex-column">
                                <i class="material-icons">get_app</i> Download Files
                            </a>
                        </div>
                    </div>
                    <!-- <div class="card">
                        <div class="card-header">
                            <div class="media align-items-center">
                                <div class="media-left">
                                    <img src="assets/images/people/110/guy-6.jpg" alt="About Adrian" width="50" class="rounded-circle">
                                </div>
                                <div class="media-body">
                                    <h4 class="card-title"><a href="instructor-profile.html">Adrian Demian</a></h4>
                                    <p class="card-subtitle">Instructor</p>
                                </div>
                            </div>
                        </div>
                        <div class="card-body">
                            <p>Having over 12 years exp. Adrian is one of the lead UI designers in the industry Lorem ipsum dolor sit amet, consectetur adipisicing elit. Facere, aut.</p>
                            <a href="#" class="btn btn-light"><i class="fab fa-facebook"></i></a>
                            <a href="#" class="btn btn-light"><i class="fab fa-twitter"></i></a>
                            <a href="#" class="btn btn-light"><i class="fab fa-github"></i></a>
                        </div>
                    </div> -->

                    <div class="card">
                        <ul class="list-group list-group-fit">
                            <li class="list-group-item">
                                <div class="media align-items-center">
                                    <div class="media-left">
                                        <i class="material-icons text-muted-light">schedule</i>
                                    </div>
                                    <div class="media-body">
                                        2 <small class="text-muted">hrs</small> &nbsp; 26 <small class="text-muted">min</small>
                                    </div>
                                </div>
                            </li>
                            <li class="list-group-item">
                                <div class="media align-items-center">
                                    <div class="media-left">
                                        <i class="material-icons text-muted-light">assessment</i>
                                    </div>
                                    <div class="media-body">Beginner</div>
                                </div>
                            </li>
                        </ul>
                    </div>

                    <!-- <div class="card">
                        <div class="card-header">
                            <h4 class="card-title">Ratings</h4>
                        </div>
                        <div class="card-body">
                            <div class="rating">
                                <i class="material-icons">star</i>
                                <i class="material-icons">star</i>
                                <i class="material-icons">star</i>
                                <i class="material-icons">star</i>
                                <i class="material-icons">star_border</i>
                            </div>
                            <small class="text-muted">20 ratings</small>
                        </div>
                    </div>

                    <a href="student-help-center.html" class="btn btn-default btn-block">
                        <i class="material-icons btn__icon--left">help</i> Get Help
                    </a> -->
                </div>
            </div>
        </div>

    </div>




<?php include 'footer_student.php'; ?>