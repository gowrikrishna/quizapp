<?php 
error_reporting( ~E_NOTICE );
require_once 'config.php';

session_start();
if(!isset($_SESSION['login_user']))
	{
		header("Location:login.php");
	}

if(isset($_GET['edit']))
{
    $sql="SELECT * FROM tbl_quiz WHERE quizid=".$_GET['edit']." ";
    $result = $db->query($sql);
    if ($result->num_rows > 0)
    {
      
        $row=$result->fetch_assoc();
        $title = $row['quiz_title'];
        $course = $row['course'];
        $videourl = $row['image'];
        $timeframe = $row['timeframe'];
        $timecount = $row['timecount'];
        $frametype = $row['frametype'];
    }
}

if(isset($_POST['btnsubmit']))
{
    $title = $_POST['quiztitle'];
    $course = $_POST['course'];
    $timeframe = $_POST['timeframe'];
    $timecount = $_POST['timecount'];
    $frametype = $_POST['frametype'];

    
	$imgFile = $_FILES['quizimage']['name'];
	$tmp_dir = $_FILES['quizimage']['tmp_name'];
    $imgSize = $_FILES['quizimage']['size'];

    if(isset($_GET['edit']))
    {
        $sql = "UPDATE tbl_quiz
                SET quiztitle='$title',course='$course',timeframe='$timeframe,
                timecount='$timecount',frametype='$frametype'
                WHERE quizid=".$_GET['edit']." ";

                                    
        mysqli_query($db, $sql);


        echo( $sql);
            // echo('Successfully Updated ...');
    }
    else
    {
        if(empty($title))
        {
            $errMSG = "Please Enter title.";
        }
        elseif(empty($course))
        {
            $errMSG = "Please Choose course.";
        }
        elseif(empty($timeframe))
        {
            $errMSG = "Please select time frame.";
        }
        elseif(empty($timecount))
        {
            $errMSG= "Please enter time duration.";
        }
        elseif(empty($imgFile))
        {
            $errMSG = "Please choose image.";
        }
        else
        {
            // $successMSG= " Data added successfully";
            $upload_dir = 'assets/images/video/'; // upload directory 
            $imgExt = strtolower(pathinfo($imgFile,PATHINFO_EXTENSION)); // get image extension
      
			// valid image extensions
			$valid_extensions = array('jpeg', 'jpg', 'png', 'gif'); // valid extensions
		
			// rename uploading image
            $pimage = rand(1000,100000).".".$imgExt;
				
 

			// allow valid image file formats
            if(in_array($imgExt, $valid_extensions))
            {			
                // Check file size '5MB'
                if($imgSize < 5000000)				
                {
                    $res = move_uploaded_file($tmp_dir,$upload_dir.$pimage);
                    // echo $res;
                    if($res)
                    {
                        $sql = "INSERT INTO tbl_quiz(quiz_title,course,image,timeframe,timecount,frametype) VALUES('$title','$course','$pimage','$timeframe','$timecount','$frametype')";
                        mysqli_query($db, $sql);
                        if ($db->query($sql) === TRUE) {
                            $last_id = $db->insert_id;
                            // $successMSG = "Successfully added";

                            header("Location: addquiz.php?edit=".$last_id);

                        } else {
                            $errMSG = "Error: " . $sql . "<br>" . $db->error;
                        }
                        
                
                        
                    }
                    else
                    {
                        $errMSG = "Unable to upload image";
                    }
            
                }
                else
                {
                    $errMSG = "Sorry, your file is too large.";
                }
			}
            else
            {
				$errMSG = "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";		
			}

        }
    

}
}


?>



<?php  include 'header.php'; ?>

   <!-- Header Layout Content -->
   <div class="mdk-header-layout__content">

<div data-push data-responsive-width="992px" class="mdk-drawer-layout js-mdk-drawer-layout">
    <div class="mdk-drawer-layout__content page ">

        <div class="container-fluid page__container">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="instructor-dashboard.html">Home</a></li>
                <li class="breadcrumb-item"><a href="instructor-quizzes.html">Quiz Manager</a></li>
                <li class="breadcrumb-item active">Edit Quiz</li>
            </ol>
            <h1 class="h2">Deploy Quiz</h1>
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Basic</h4>
                </div>
                <div class="card-body">
                <form class="form-horizontal" method="post" enctype="multipart/form-data">
                        <div class="form-group row">
                            <label for="quiz_title" class="col-sm-3 col-form-label form-label">Quiz Title:</label>
                            <div class="col-sm-9">
                                <input id="quiz_title" name="quiztitle" value="<?php echo $title; ?>" type="text" class="form-control" placeholder="Title" value="">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="course_title" class="col-sm-3 col-form-label form-label">Course:</label>
                            <div class="col-sm-9 col-md-4">
                                <select id="course_title" name="course" class="custom-select form-control">
<?php
$dd_res="SELECT * FROM tbl_course";
$result = $db->query($dd_res);
if ($result->num_rows > 0) {
    while($row=$result->fetch_assoc())
    {
        extract($row);
            
?>
                                    <option value="<?php echo $courseid; ?>"><?php echo $title; ?></option>

    <?php } } ?>                                  
                                </select>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="avatar" class="col-sm-3 col-form-label form-label">Quiz Image:</label>
                            <div class="col-sm-9 col-md-4">
                                <p> <img src="#" id="imgPrev" width="150" class="rounded"></p>
                                <div class="custom-file">
                                    <input type="file" name="quizimage" id="avatar" class="custom-file-input">
                                    <label for="avatar" class="custom-file-label">Choose file</label>
                                </div>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="cmn-toggle" class="col-sm-3 col-form-label form-label">Timeframe</label>
                            <div class="col-sm-9">
                                <div class="form-group">
                                    <div class="custom-control custom-checkbox-toggle">
                                        <input id="cmn-toggle" name="timeframe" type="checkbox" aria-checked="false" class="custom-control-input" role="switch">
                                        <label class="custom-control-label" for="cmn-toggle"><span class="sr-only">Timeframe</span></label>
                                    </div>
                                </div>
                                <div class="form-inline">
                                    <div class="form-group mr-2">
                                        <input type="number" class="form-control text-center" value="<?php echo $timecount; ?>" name="timecount" style="width:50px;">
                                    </div>
                                    <div class="form-group">
                                        <select class="custom-select" name="frametype">
                                            <option value="hour" selected>Hours</option>
                                            <option value="minutes">Minutes</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group row mb-0">
                            <div class="col-sm-4">
                                <button type="submit" name="btnsubmit" class="btn btn-success">Save</button>
                            </div>
                            <div class="col-sm-8">
                            <?php
	if(isset($errMSG)){
			?>
            <div class="alert alert-danger">
            	<span class="glyphicon glyphicon-info-sign"></span> <strong><?php echo $errMSG; ?></strong>
            </div>
            <?php
	}
	else if(isset($successMSG)){
		?>
        <div class="alert alert-success">
              <strong><span class="glyphicon glyphicon-info-sign"></span> <?php echo $successMSG; ?></strong>
        </div>
        <?php
	}
	?>  
                            </div>

                        </div>
                    </form>
                </div>
            </div>
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Questions</h4>
                </div>
                <div class="card-header">
                    <a href="#" data-toggle="modal" data-id="<?php echo $_GET['edit']; ?>" data-target="#editQuiz" class="btn btn-outline-secondary">Add Question <i class="material-icons">add</i></a>
                </div>
                <div class="nestable" id="nestable">
                    <ul class="list-group list-group-fit nestable-list-plain mb-0">
                    <?php
                    if(isset($_GET['edit']))
                    {
                $dd_res="SELECT * FROM tbl_questions WHERE quiz=".$_GET['edit'];
                $result = $db->query($dd_res);

                if ($result->num_rows > 0) {
                while($row=$result->fetch_assoc())
                {
                  
            ?>
                        <li class="list-group-item nestable-item">
                            <div class="media align-items-center">
                                <div class="media-left">
                                    <a href="#" class="btn btn-default nestable-handle"><i class="material-icons">menu</i></a>
                                </div>
                                <div class="media-body">
                                    <?php echo $row['title']; ?>
                                </div>
                                <div class="media-right text-right">
                                    <div style="width:100px">
                                        <a href="#" data-toggle="modal" data-target="#editQuiz" class="btn btn-primary btn-sm"><i class="material-icons">edit</i></a>
                                    </div>
                                </div>
                            </div>
                        </li>

                        <?php } } }?>
                        <!-- <li class="list-group-item nestable-item">
                            <div class="media align-items-center">
                                <div class="media-left">
                                    <a href="#" class="btn btn-default nestable-handle"><i class="material-icons">menu</i></a>
                                </div>
                                <div class="media-body">
                                    The MVC architectural pattern
                                </div>
                                <div class="media-right text-right">
                                    <div style="width:100px">
                                        <a href="#" data-toggle="modal" data-target="#editQuiz" class="btn btn-primary btn-sm"><i class="material-icons">edit</i></a>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li class="list-group-item nestable-item">
                            <div class="media align-items-center">
                                <div class="media-left">
                                    <a href="#" class="btn btn-default nestable-handle"><i class="material-icons">menu</i></a>
                                </div>
                                <div class="media-body">
                                    Database Models
                                </div>
                                <div class="media-right text-right">
                                    <div style="width:100px">
                                        <a href="#" data-toggle="modal" data-target="#editQuiz" class="btn btn-primary btn-sm"><i class="material-icons">edit</i></a>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li class="list-group-item nestable-item" data-id="4">
                            <div class="media align-items-center">
                                <div class="media-left">
                                    <a href="#" class="btn btn-default nestable-handle"><i class="material-icons">menu</i></a>
                                </div>
                                <div class="media-body">
                                    Database Access
                                </div>
                                <div class="media-right text-right">
                                    <div style="width:100px">
                                        <a href="#" data-toggle="modal" data-target="#editQuiz" class="btn btn-primary btn-sm"><i class="material-icons">edit</i></a>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li class="list-group-item nestable-item" data-id="5">
                            <div class="media align-items-center">
                                <div class="media-left">
                                    <a href="#" class="btn btn-default nestable-handle"><i class="material-icons">menu</i></a>
                                </div>
                                <div class="media-body">
                                    Eloquent Basics
                                </div>
                                <div class="media-right text-right">
                                    <div style="width:100px">
                                        <a href="#" data-toggle="modal" data-target="#editQuiz" class="btn btn-primary btn-sm"><i class="material-icons">edit</i></a>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li class="list-group-item nestable-item" data-id="6"> -->
                            <div class="media align-items-center">
                                <div class="media-left">
                                    <a href="#" class="btn btn-default nestable-handle"><i class="material-icons">menu</i></a>
                                </div>
                                <div class="media-body">
                                    Take Quiz
                                </div>
                                <div class="media-right text-right">
                                    <div style="width:100px">
                                        <a href="#" data-toggle="modal"  data-target="#editQuiz" class="btn btn-primary btn-sm"><i class="material-icons">edit</i></a>
                                    </div>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>

    </div>



 
  




    <!-- App Settings FAB -->
    <div id="app-settings">
                <app-settings layout-active="default" :layout-location="{
      'fixed': 'fixed-addquiz.php',
      'default': 'assquiz.php'
    }" sidebar-variant="bg-transparent border-0"></app-settings>
            </div>








<?php  include 'footer.php'; ?>