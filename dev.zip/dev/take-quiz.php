<?php 
error_reporting( ~E_NOTICE );
require_once 'config.php';

session_start();
if(!isset($_SESSION['login_user']))
	{
		header("Location:login.php");
	}









?>
<?php
include 'header.php';
?>



 <!-- Header Layout Content -->
 <div class="mdk-header-layout__content">

<div data-push="" data-responsive-width="992px" class="mdk-drawer-layout js-mdk-drawer-layout">
    <div class="mdk-drawer-layout__content page ">

        <div class="container-fluid page__container">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="dashboard.html">Home</a></li>
                <li class="breadcrumb-item active">Quiz</li>
            </ol>
            <div class="card-group">
                <div class="card">
                    <div class="card-body text-center">
                        <h4 class="mb-0"><strong>25</strong></h4>
                        <small class="text-muted-light">TOTAL</small>
                    </div>
                </div>
                <div class="card">
                    <div class="card-body text-center">
                        <h4 class="text-success mb-0"><strong>3</strong></h4>
                        <small class="text-muted-light">CORECT</small>
                    </div>
                </div>
                <div class="card">
                    <div class="card-body text-center">
                        <h4 class="text-danger mb-0"><strong>5</strong></h4>
                        <small class="text-muted-light">WRONG</small>
                    </div>
                </div>
                <div class="card">
                    <div class="card-body text-center">
                        <h4 class="text-primary mb-0"><strong>17</strong></h4>
                        <small class="text-muted-light">LEFT</small>
                    </div>
                </div>
            </div>
            <?php 

if(isset($_GET['id']))
{
    $sql="SELECT qid, title, option_one, option_two, option_three, option_four, answer, score
    FROM tbl_quiz
    INNER JOIN tbl_questions ON tbl_questions.quiz = tbl_quiz.quizid
    WHERE course=".$_GET['id']." LIMIT 1 ";
}
else
{
    $sql="SELECT qid, title, option_one, option_two, option_three, option_four, answer, score
    FROM tbl_quiz
    INNER JOIN tbl_questions ON tbl_questions.quiz = tbl_quiz.quizid
    ORDER BY qid ASC LIMIT 1 ";
}
    $result = $db->query($sql);
    $count=0;
    if ($result->num_rows > 0)
    {
        $count=1;
        $row=$result->fetch_assoc();
            

?>
            <div class="card">
                <div class="card-header">
                    <div class="media align-items-center">
                        <div class="media-left">
                            <h4 class="mb-0"><strong>#<?php echo $count; ?></strong></h4>
                        </div>
                        <div class="media-body">
                            <h4 class="card-title">
                            <?php echo $row['title']; ?>
                            </h4>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <div class="form-group">
                        <div class="custom-control custom-checkbox">
                            <input id="customCheck01" type="checkbox" class="custom-control-input">
                            <label for="customCheck01" class="custom-control-label"> <?php echo $row['option_one']; ?></label>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="custom-control custom-checkbox">
                            <input id="customCheck02" type="checkbox" class="custom-control-input">
                            <label for="customCheck02" class="custom-control-label"> <?php echo $row['option_two']; ?></label>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="custom-control custom-checkbox">
                            <input id="customCheck03" type="checkbox" class="custom-control-input">
                            <label for="customCheck03" class="custom-control-label"> <?php echo $row['option_three']; ?>l</label>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="custom-control custom-checkbox">
                            <input id="customCheck04" type="checkbox" class="custom-control-input">
                            <label for="customCheck04" class="custom-control-label"> <?php echo $row['option_four']; ?>l</label>
                        </div>
                    </div>
                </div>
                <div class="card-footer">
                    <a href="#" class="btn btn-white">Skip</a>
                    <a href="#" class="btn btn-success float-right">Submit <i class="material-icons btn__icon--right">send</i></a>
                </div>
            </div>

             <?php

}




?>
        </div>

    </div>




    <div class="mdk-drawer js-mdk-drawer" data-align="end">
        <div class="mdk-drawer__content ">
            <div class="sidebar sidebar-right sidebar-light bg-white o-hidden" data-perfect-scrollbar>
                <div class="sidebar-p-y">
                    <div class="sidebar-heading">Time left</div>
                    <div class="countdown sidebar-p-x" data-value="4" data-unit="hour"></div>

                    <div class="sidebar-heading">Pending</div>
                    <ul class="list-group list-group-fit">

<?php 

if(isset($_GET['id']))
{
    $sql="SELECT qid, title, option_one, option_two, option_three, option_four, answer, score
    FROM tbl_quiz
    INNER JOIN tbl_questions ON tbl_questions.quiz = tbl_quiz.quizid
    WHERE course=".$_GET['id']." ";
}
else
{
    $sql="SELECT qid, title, option_one, option_two, option_three, option_four, answer, score
    FROM tbl_quiz
    INNER JOIN tbl_questions ON tbl_questions.quiz = tbl_quiz.quizid
    ORDER BY qid ASC LIMIT 1 ";
}
    $result = $db->query($sql);
    $count=0;
    if ($result->num_rows > 0)
    {
        while($row=$result->fetch_assoc())
        {
            $count++;
            

?>




                        <li class="list-group-item <?php if($count==1) echo "active" ?>">
                            <a href="#">
                                <span class="media align-items-center">
                                    <span class="media-left">
                                        <span class="btn btn-white btn-circle">#<?php echo $count; ?></span>
                                    </span>
                                    <span class="media-body">
                                        <?php echo $row['title']; ?>
                                    </span>
                                </span>
                            </a>
                        </li>

                        <?php

}
}



?>


<!--                         
                        
                        <li class="list-group-item">
                            <a href="#">
                                <span class="media align-items-center">
                                    <span class="media-left">
                                        <span class="btn btn-white btn-circle">#10</span>
                                    </span>
                                    <span class="media-body">
                                        What's the difference between private and public repos?
                                    </span>
                                </span>
                            </a>
                        </li>
                        <li class="list-group-item">
                            <a href="#">
                                <span class="media align-items-center">
                                    <span class="media-left">
                                        <span class="btn btn-white btn-circle">#11</span>
                                    </span>
                                    <span class="media-body">
                                        What is the purpose of a branch?
                                    </span>
                                </span>
                            </a>
                        </li>
                        <li class="list-group-item">
                            <a href="#">
                                <span class="media align-items-center">
                                    <span class="media-left">
                                        <span class="btn btn-white btn-circle">#12</span>
                                    </span>
                                    <span class="media-body">
                                        Final Question?
                                    </span>
                                </span>
                            </a>
                        </li> -->
                    </ul>
                </div>
            </div>
        </div>
    </div>

</div>

<!-- App Settings FAB -->
<div id="app-settings">
    <app-settings layout-active="default" :layout-location="{
'fixed': 'fixed-take-quiz.php',
'default': 'take-quiz.php'
}" sidebar-variant="bg-transparent border-0"></app-settings>
</div>

</div>
</div>






















<?php include 'footer_student.php'; ?>