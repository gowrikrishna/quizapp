<?php 
error_reporting( ~E_NOTICE ); // avoid notice

require_once 'config.php';


if(isset($_POST['btn_submit']))
{
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $cnpass = $_POST['cnpass'];
    $terms = $_POST['terms'];
  
    

    if(empty($name)){
        $errMSG = "Please Enter Name.";
    }
    else if(empty($email){
        $errMSG = "Please Enter Email.";
    }
    else if(empty($password)){
        $errMSG = "Please Enter Password.";
    }
    else if(empty($cnpass)){
        $errMSG = "Please Enter Confirm Password.";
    }
    else if(empty($terms)){
        $errMSG = "Please Check Terms and condition";
    }
   
    

// if no error occured, continue ....
if(!isset($errMSG))
{
    if($cnpass==$password)
    {
        $sql = "INSERT INTO tbl_register(name,email,password) VALUES ('$name','$email','$password')";
           //  echo $sql;
      mysqli_query($db, $sql);
 

      $successMSG="Thank you for registering";
    //  header("refresh:1;registration.php");
    //$stmt = $DB_con->prepare( $sql);
     
    
    // if($stmt->execute())
    // {
    // 	$successMSG = "new record succesfully inserted ...";
    // 	header("refresh:5;index.php"); // redirects image view page after 5 seconds.
    // }
    // else
    // {
    // 	$errMSG = "error while inserting....";
    // }
    }
    else
    {
        $errMSG="Confirm password showing mismatch.";
    }

      
}





}




?>











<!DOCTYPE html>
<html lang="en" dir="ltr">


<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Signup</title>

      
     

    <!-- Perfect Scrollbar -->
    <link type="text/css" href="assets/vendor/perfect-scrollbar.css" rel="stylesheet">

    <!-- Material Design Icons -->
    <link type="text/css" href="assets/css/material-icons.css" rel="stylesheet">
    <link type="text/css" href="assets/css/material-icons.rtl.css" rel="stylesheet">

    <!-- Font Awesome Icons -->
    <link type="text/css" href="assets/css/fontawesome.css" rel="stylesheet">
    <link type="text/css" href="assets/css/fontawesome.rtl.css" rel="stylesheet">

    <!-- App CSS -->
    <link type="text/css" href="assets/css/app.css" rel="stylesheet">
    <link type="text/css" href="assets/css/app.rtl.css" rel="stylesheet">





</head>

<body class="login">


    <div class="d-flex align-items-center" style="min-height: 100vh">
        <div class="col-sm-8 col-md-6 col-lg-4 mx-auto" style="min-width: 300px;">
            <div class="text-center mt-5 mb-1">
                <div class="avatar avatar-lg">
                    <img src="assets/img/logo.png" class="avatar-img" alt="LearnPlus" />
                </div>
            </div>
           
            <div class="card navbar-shadow">
                <div class="card-header text-center">
                    <h4 class="card-title">Sign Up</h4>
                    <p class="card-subtitle">Create a new account</p>
                </div>
                <div class="card-body">

                    <!-- <a href="dashboard.html" class="btn btn-light btn-block">
                        <span class="fab fa-google mr-2"></span>
                        Continue with Google
                    </a>

                    <div class="page-separator">
                        <div class="page-separator__text">or</div>
                    </div> -->

                    <!-- <form action="http://learnplus-bootstrap.frontendmatter.com/dashboard.html" novalidate method="get"> -->
                    <form class="form-horizontal" method="post" enctype="multipart/form-data">
                        <div class="form-group">
                            <label class="form-label" for="name">Name:</label>
                            <div class="input-group input-group-merge">
                                <input id="name" type="text" name="name" required="" class="form-control form-control-prepended" placeholder="Your first and last name">
                                <div class="input-group-prepend">
                                    <div class="input-group-text">
                                        <span class="far fa-user"></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="form-label" for="email">Email address:</label>
                            <div class="input-group input-group-merge">
                                <input id="email" type="email" name="email" required="" class="form-control form-control-prepended" placeholder="Your email address">
                                <div class="input-group-prepend">
                                    <div class="input-group-text">
                                        <span class="far fa-envelope"></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="form-label" for="password">Password:</label>
                            <div class="input-group input-group-merge">
                                <input id="password" type="password" name="password" required="" class="form-control form-control-prepended" placeholder="Choose a password">
                                <div class="input-group-prepend">
                                    <div class="input-group-text">
                                        <span class="fas fa-key"></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="form-label" for="password2">Password:</label>
                            <div class="input-group input-group-merge">
                                <input id="password2" type="password" name="cnpass" required="" class="form-control form-control-prepended" placeholder="Confirm password">
                                <div class="input-group-prepend">
                                    <div class="input-group-text">
                                        <span class="fas fa-key"></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <button type="submit" name="btnsubmit" class="btn btn-primary btn-block mb-3">Sign Up</button>
                        <div class="form-group text-center mb-0">
                            <div class="custom-control custom-checkbox">
                                <input id="terms" name="terms" type="checkbox" class="custom-control-input" checked required="">
                                <label for="terms" class="custom-control-label text-black-70">I agree to the <a href="#" class="text-black-70" style="text-decoration: underline;">Terms of Use</a></label>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="card-footer text-center text-black-50">Already signed up? <a href="login.php">Login</a></div>
            </div>
        </div>
    </div>


    <!-- jQuery -->
    <script src="assets/vendor/jquery.min.js"></script>

    <!-- Bootstrap -->
    <script src="assets/vendor/popper.min.js"></script>
    <script src="assets/vendor/bootstrap.min.js"></script>

    <!-- Perfect Scrollbar -->
    <script src="assets/vendor/perfect-scrollbar.min.js"></script>

    <!-- MDK -->
    <script src="assets/vendor/dom-factory.js"></script>
    <script src="assets/vendor/material-design-kit.js"></script>

    <!-- App JS -->
    <script src="assets/js/app.js"></script>

    <!-- Highlight.js -->
    <script src="assets/js/hljs.js"></script>

    <!-- App Settings (safe to remove) -->
    <script src="assets/js/app-settings.js"></script>





</body>


</html>